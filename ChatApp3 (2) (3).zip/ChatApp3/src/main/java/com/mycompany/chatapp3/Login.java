
package com.mycompany.chatapp3;

public class Login {

    private String firstName;
    private String lastName;
    private String username;
    private String password;
    private String cellPhoneNumber;

    private boolean registered;

    // Constructor matching ChatApp3.java
    public Login(String firstName,
                 String lastName,
                 String username,
                 String password,
                 String cellPhoneNumber) {

        this.firstName = firstName;
        this.lastName = lastName;
        this.username = username;
        this.password = password;
        this.cellPhoneNumber = cellPhoneNumber;

        this.registered = false;
    }

    // Username must contain an underscore and be no longer than 5 characters.
    public boolean checkUserName() {
        return username != null
                && username.length() <= 5
                && username.contains("_");
    }

    // Password must have at least 8 characters, an uppercase letter,
    // a number and a special character.
    public boolean checkPasswordComplexity() {
        return password != null
                && password.length() >= 8
                && password.matches(".*[A-Z].*")
                && password.matches(".*[0-9].*")
                && password.matches(".*[^A-Za-z0-9].*");
    }

    // Accept a South African number in international format: +27XXXXXXXXX.
    public boolean checkCellPhoneNumber() {
        return cellPhoneNumber != null
                && cellPhoneNumber.matches("^\\+27[0-9]{9}$");
    }

    // Validate the registration details.
    public String registerUser() {

        if (!checkUserName()) {
            registered = false;
            return "Username is not correctly formatted: "
                    + "please ensure that your username contains "
                    + "an underscore and is no more than five "
                    + "characters long.";
        }

        if (!checkPasswordComplexity()) {
            registered = false;
            return "Password is not correctly formatted: "
                    + "please ensure that the password contains "
                    + "at least eight characters, a capital letter, "
                    + "a number and a special character.";
        }

        if (!checkCellPhoneNumber()) {
            registered = false;
            return "Cell phone number is incorrectly formatted. "
                    + "Please enter a South African number in "
                    + "international format, for example "
                    + "+27832490641.";
        }

        registered = true;
        return "Registration successful.";
    }

    // Check the login credentials.
    public boolean loginUser(String enteredUsername,
                             String enteredPassword) {

        return registered
                && enteredUsername != null
                && enteredPassword != null
                && username.equals(enteredUsername)
                && password.equals(enteredPassword);
    }

    // Return a message indicating whether login succeeded.
    public String returnLoginStatus(boolean loginSuccessful) {

        if (loginSuccessful) {
            return "Login successful. Welcome "
                    + firstName + " " + lastName + "!";
        }

        return "Login failed. Please check your username and password.";
    }

    // Getters
    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getUsername() {
        return username;
    }

    public String getCellPhoneNumber() {
        return cellPhoneNumber;
    }
}
