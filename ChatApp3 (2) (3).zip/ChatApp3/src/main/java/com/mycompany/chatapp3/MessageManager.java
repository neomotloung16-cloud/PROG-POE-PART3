
package com.mycompany.chatapp3;

import java.util.ArrayList;
import java.util.List;

public class MessageManager {

    private final List<Message> sentMessages = new ArrayList<>();
    private final List<Message> storedMessages = new ArrayList<>();
    private final List<Message> discardedMessages = new ArrayList<>();

    public String processMessage(Message message, String action) {

        if (message == null) {
            return "Invalid message.";
        }

        if (action == null) {
            return "Invalid option. Choose Send, Store or Discard.";
        }

        String result = message.sendMessage(action);

        if (result.equals("Message successfully sent.")) {
            sentMessages.add(message);

        } else if (result.equals("Message successfully stored.")) {
            storedMessages.add(message);

        } else if (result.equals("Message discarded.")) {
            discardedMessages.add(message);
        }

        return result;
    }

    public String displaySentMessages() {
        if (sentMessages.isEmpty()) {
            return "No sent messages yet.";
        }

        StringBuilder output = new StringBuilder();

        for (Message message : sentMessages) {
            output.append("Message ID: ")
                    .append(message.getMessageID())
                    .append("\nMessage Hash: ")
                    .append(message.getMessageHash())
                    .append("\nRecipient: ")
                    .append(message.getRecipient())
                    .append("\nMessage: ")
                    .append(message.getMessageText())
                    .append("\n--------------------------\n");
        }

        return output.toString();
    }

    public String displayStoredMessages() {
        if (storedMessages.isEmpty()) {
            return "No stored messages yet.";
        }

        StringBuilder output = new StringBuilder();

        for (Message message : storedMessages) {
            output.append("Message ID: ")
                    .append(message.getMessageID())
                    .append("\nMessage Hash: ")
                    .append(message.getMessageHash())
                    .append("\nRecipient: ")
                    .append(message.getRecipient())
                    .append("\nMessage: ")
                    .append(message.getMessageText())
                    .append("\n--------------------------\n");
        }

        return output.toString();
    }

    public int getTotalMessagesSent() {
        return sentMessages.size();
    }

    public int getTotalMessagesStored() {
        return storedMessages.size();
    }

    public int getTotalMessagesDiscarded() {
        return discardedMessages.size();
    }
}
