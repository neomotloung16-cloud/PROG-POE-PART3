
package com.mycompany.chatapp3;

import java.util.Scanner;

public class ChatApp3 {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.println("====================================");
        System.out.println("              CHATAPP");
        System.out.println("            REGISTRATION");
        System.out.println("====================================");

        System.out.print("Enter your first name: ");
        String firstName = input.nextLine();

        System.out.print("Enter your last name: ");
        String lastName = input.nextLine();

        System.out.print("Enter your username: ");
        String username = input.nextLine();

        System.out.print("Enter your password: ");
        String password = input.nextLine();

        System.out.print("Enter your South African cell phone number: ");
        String cellPhoneNumber = input.nextLine();

        Login user = new Login(
                firstName,
                lastName,
                username,
                password,
                cellPhoneNumber
        );

        System.out.println();
        System.out.println(user.registerUser());

        // Continue only if registration details are valid.
        if (user.checkUserName()
                && user.checkPasswordComplexity()
                && user.checkCellPhoneNumber()) {

            System.out.println();
            System.out.println("====================================");
            System.out.println("                LOGIN");
            System.out.println("====================================");

            System.out.print("Enter username: ");
            String enteredUsername = input.nextLine();

            System.out.print("Enter password: ");
            String enteredPassword = input.nextLine();

            boolean loginSuccessful =
                    user.loginUser(enteredUsername, enteredPassword);

            System.out.println(
                    user.returnLoginStatus(loginSuccessful)
            );

            // Only logged-in users can access QuickChat.
            if (loginSuccessful) {

                System.out.println();
                System.out.println("Welcome to QuickChat!");

                int messageLimit = 0;

                // Ask the user how many messages they want to process.
                while (true) {
                    System.out.print(
                            "How many messages would you like to send? "
                    );

                    try {
                        messageLimit =
                                Integer.parseInt(input.nextLine());

                        if (messageLimit > 0) {
                            break;
                        }

                        System.out.println(
                                "Enter a number greater than zero."
                        );

                    } catch (NumberFormatException e) {
                        System.out.println(
                                "Enter a valid whole number."
                        );
                    }
                }

                int messageNumber = 0;
                int choice = 0;

                // Main QuickChat menu.
                while (choice != 3) {

                    System.out.println("\n====================================");
                    System.out.println("            QUICKCHAT MENU");
                    System.out.println("====================================");
                    System.out.println("1. Send Messages");
                    System.out.println("2. Show recently sent messages");
                    System.out.println("3. Quit");
                    System.out.print("Choose an option: ");

                    try {
                        choice = Integer.parseInt(input.nextLine());
                    } catch (NumberFormatException e) {
                        System.out.println(
                                "Please enter 1, 2 or 3."
                        );
                        continue;
                    }

                    switch (choice) {

                        case 1:

                            if (messageNumber >= messageLimit) {
                                System.out.println(
                                        "Message limit reached."
                                );
                                break;
                            }

                            System.out.print(
                                    "Enter recipient number "
                                    + "(+27 followed by 9 digits): "
                            );
                            String recipient = input.nextLine();

                            System.out.print("Enter your message: ");
                            String messageText = input.nextLine();

                            Message newMessage = new Message(
                                    recipient,
                                    messageText,
                                    messageNumber + 1
                            );

                            System.out.println(
                                    "Valid recipient number: "
                                    + newMessage.checkRecipientCell()
                            );

                            System.out.println(
                                    "Valid message length: "
                                    + newMessage.validateMessageLength()
                            );

                            System.out.println(
                                    "Message ID: "
                                    + newMessage.getMessageID()
                            );

                            System.out.println(
                                    "Message Hash: "
                                    + newMessage.getMessageHash()
                            );

                            System.out.println(
                                    "Choose an action: Send, Store or Discard"
                            );
                            String action = input.nextLine();

                            String result =
                                    newMessage.sendMessage(action);

                            System.out.println(result);

                            // Count successfully sent or stored messages.
                            if (result.equals(
                                    "Message successfully sent.")
                                    || result.equals(
                                    "Message successfully stored.")) {

                                messageNumber++;
                            }

                            break;

                        case 2:

                            Message displayMessage =
                                    new Message("", "Display", 0);

                            System.out.println(
                                    displayMessage.printMessages()
                            );

                            System.out.println(
                                    "Total messages sent: "
                                    + displayMessage.returnTotalMessages()
                            );

                            break;

                        case 3:

                            System.out.println(
                                    "Thank you for using QuickChat."
                            );

                            break;

                        default:

                            System.out.println(
                                    "Please choose 1, 2 or 3."
                            );
                    }
                }
            }

        } else {
            System.out.println();
            System.out.println(
                    "Registration unsuccessful. Please check your details."
            );
        }

        input.close();
    }
}
