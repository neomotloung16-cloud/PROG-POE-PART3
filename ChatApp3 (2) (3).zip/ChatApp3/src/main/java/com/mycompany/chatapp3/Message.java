
package com.mycompany.chatapp3;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.regex.Pattern;

public class Message {

    private String recipient;
    private String messageText;
    private int messageNumber;
    private String messageID;
    private String messageHash;

    private static final List<String> SENT_MESSAGES = new ArrayList<>();
    private static final List<String> STORED_MESSAGES = new ArrayList<>();
    private static int totalMessagesSent = 0;

    public Message(String recipient, String text, int messageNumber) {
        this.recipient = recipient;
        this.messageText = text;
        this.messageNumber = messageNumber;

        this.messageID = UUID.randomUUID()
                .toString()
                .replace("-", "")
                .substring(0, 10);

        this.messageHash = createMessageHash();
    }

    public boolean checkRecipientCell() {
        return recipient != null
                && Pattern.matches("^\\+27[0-9]{9}$", recipient);
    }

    public boolean validateMessageLength() {
        return messageText != null && messageText.length() <= 250;
    }

    private String createMessageHash() {
        if (messageText == null || messageText.trim().isEmpty()) {
            return messageNumber + ":" + messageID + ":";
        }

        String[] words = messageText.trim().split("\\s+");
        String firstWord = words[0];
        String lastWord = words[words.length - 1];

        return (messageNumber + ":" + messageID + ":"
                + firstWord + ":" + lastWord).toUpperCase();
    }

    public String sendMessage(String action) {
        if (!checkRecipientCell()) {
            return "Invalid recipient cellphone number.";
        }

        if (!validateMessageLength()) {
            return "Message exceeds 250 characters.";
        }

        if (action == null) {
            return "Invalid option.";
        }

        switch (action.trim().toLowerCase()) {
            case "send":
                SENT_MESSAGES.add(formatMessage());
                totalMessagesSent++;
                return "Message successfully sent.";

            case "store":
                STORED_MESSAGES.add(formatMessage());
                return "Message successfully stored.";

            case "discard":
                return "Message discarded.";

            default:
                return "Invalid option. Choose Send, Store or Discard.";
        }
    }

    private String formatMessage() {
        return "Message ID: " + messageID
                + "\nMessage Hash: " + messageHash
                + "\nRecipient: " + recipient
                + "\nMessage: " + messageText;
    }

    public String printMessages() {
        if (SENT_MESSAGES.isEmpty()) {
            return "No sent messages yet.";
        }

        StringBuilder output = new StringBuilder();

        for (String message : SENT_MESSAGES) {
            output.append(message).append("\n--------------------\n");
        }

        return output.toString();
    }

    public int returnTotalMessages() {
        return totalMessagesSent;
    }

    public String getMessageID() {
        return messageID;
    }

    public String getMessageHash() {
        return messageHash;
    }

    public String getRecipient() {
        return recipient;
    }

    public String getMessageText() {
        return messageText;
    }

    public int getMessageNumber() {
        return messageNumber;
    }
}
