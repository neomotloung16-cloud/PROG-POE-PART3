
package com.mycompany.chatapp3;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class MessageTest {

    private Message message;

    @BeforeEach
    public void setUp() {
        message = new Message(
                "+27827597588",
                "Hi Keegan",
                1
        );
    }

    @Test
    public void testCheckRecipientCellValid() {
        assertTrue(message.checkRecipientCell());
    }

    @Test
    public void testCheckRecipientCellInvalid() {
        Message invalidMessage =
                new Message("0827597588", "Hi Keegan", 1);

        assertFalse(invalidMessage.checkRecipientCell());
    }

    @Test
    public void testValidateMessageLengthValid() {
        assertTrue(message.validateMessageLength());
    }

    @Test
    public void testValidateMessageLengthInvalid() {
        String longText = "A".repeat(251);

        Message longMessage =
                new Message("+27827597588", longText, 1);

        assertFalse(longMessage.validateMessageLength());
    }

    @Test
    public void testMessageIDIsGenerated() {
        assertNotNull(message.getMessageID());
        assertFalse(message.getMessageID().isEmpty());
    }

    @Test
    public void testMessageHashIsGenerated() {
        assertNotNull(message.getMessageHash());
        assertFalse(message.getMessageHash().isEmpty());
    }

    @Test
    public void testSendMessage() {
        assertEquals(
                "Message successfully sent.",
                message.sendMessage("Send")
        );
    }

    @Test
    public void testStoreMessage() {
        assertEquals(
                "Message successfully stored.",
                message.sendMessage("Store")
        );
    }

    @Test
    public void testDiscardMessage() {
        assertEquals(
                "Message discarded.",
                message.sendMessage("Discard")
        );
    }

    @Test
    public void testInvalidAction() {
        assertEquals(
                "Invalid option. Choose Send, Store or Discard.",
                message.sendMessage("Unknown")
        );
    }

    @Test
    public void testInvalidRecipientCannotSend() {
        Message invalidMessage =
                new Message("12345", "Hello", 1);

        assertEquals(
                "Invalid recipient cellphone number.",
                invalidMessage.sendMessage("Send")
        );
    }

    @Test
    public void testMessageTooLongCannotSend() {
        String longText = "A".repeat(251);

        Message invalidMessage =
                new Message("+27827597588", longText, 1);

        assertEquals(
                "Message exceeds 250 characters.",
                invalidMessage.sendMessage("Send")
        );
    }
}
