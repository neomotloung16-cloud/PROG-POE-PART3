/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.chatapp3;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Student
 */
public class LoginTest {
    
     @Test
    public void testCheckUserName() {

        Login user = new Login(
                "Kyle",
                "Smith",
                "kyl_1",
                "ChR&8ec@ke99!",
                "+27838968976"
        );

        assertTrue(user.checkUserName());
    }

    @Test
    public void testCheckPasswordComplexity() {

        Login user = new Login(
                "Kyle",
                "Smith",
                "kyl_1",
                "ChR&8ec@ke99!",
                "+27838968976"
        );

        assertTrue(user.checkPasswordComplexity());
    }

    @Test
    public void testCheckCellPhoneNumber() {

        Login user = new Login(
                "Kyle",
                "Smith",
                "kyl_1",
                "ChR&8ec@ke99!",
                "+27838968976"
        );

        assertTrue(user.checkCellPhoneNumber());
    }

    @Test
    public void testRegisterUser() {

        Login user = new Login(
                "Kyle",
                "Smith",
                "kyl_1",
                "ChR&8ec@ke99!",
                "+27838968976"
        );

        assertEquals(
                "User has been registered successfully.",
                user.registerUser()
        );
    }

    @Test
    public void testLoginUser() {

        Login user = new Login(
                "Kyle",
                "Smith",
                "kyl_1",
                "ChR&8ec@ke99!",
                "+27838968976"
        );

        assertTrue(user.loginUser("kyl_1", "ChR&8ec@ke99!"));

        assertFalse(user.loginUser("wrong", "wrong"));
    }

    @Test
    public void testReturnLoginStatus() {

        Login user = new Login(
                "Kyle",
                "Smith",
                "kyl_1",
                "ChR&8ec@ke99!",
                "+27838968976"
        );

        assertEquals(
                "A successful login",
                user.returnLoginStatus(true)
        );

        assertEquals(
                "A failed login",
                user.returnLoginStatus(false)
        );
    }

    @Test
    public void testGetFirstName() {

        Login user = new Login(
                "Kyle",
                "Smith",
                "kyl_1",
                "ChR&8ec@ke99!",
                "+27838968976"
        );

        assertEquals("Kyle", user.getFirstName());
    }

    @Test
    public void testGetLastName() {

        Login user = new Login(
                "Kyle",
                "Smith",
                "kyl_1",
                "ChR&8ec@ke99!",
                "+27838968976"
        );

        assertEquals("Smith", user.getLastName());
    }
}